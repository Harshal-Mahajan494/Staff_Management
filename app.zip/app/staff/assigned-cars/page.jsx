'use client';
import { useState, useEffect } from 'react';

const availableCars = [
  { id: 101, model: 'Toyota Camry', type: 'Sedan', status: 'Available', registrationNumber: 'MH12AB1234', fuelStatus: 'Full', imageUrl: '/images/Compact1.jpg' },
  { id: 102, model: 'Honda CR-V', type: 'SUV', status: 'Available', registrationNumber: 'MH12CD5678', fuelStatus: 'Half', imageUrl: '/images/Compact1.jpg' },
  { id: 103, model: 'Ford Transit', type: 'Van', status: 'Available', registrationNumber: 'MH12EF9012', fuelStatus: 'Full', imageUrl: '/images/Compact1.jpg' },
  { id: 104, model: 'Nissan Altima', type: 'Sedan', status: 'Available', registrationNumber: 'MH12GH3456', fuelStatus: 'Low', imageUrl: '/images/Compact1.jpg' },
  { id: 105, model: 'Chevrolet Tahoe', type: 'SUV', status: 'Available', registrationNumber: 'MH12IJ7890', fuelStatus: 'Full', imageUrl: '/images/Compact1.jpg' },
  { id: 106, model: 'Mercedes Sprinter', type: 'Van', status: 'Booked', registrationNumber: 'MH12KL4321', fuelStatus: 'Full', imageUrl: '/images/Compact1.jpg' },
];

export default function Home() {
  const [userData, setUserData] = useState([]);
  const [assignedCars, setAssignedCars] = useState({});
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedCar, setSelectedCar] = useState('');
  const [showFuelPopup, setShowFuelPopup] = useState(false);
  const [selectedFuelStatus, setSelectedFuelStatus] = useState('');

  const UserData = [
    {
      id: 1,
      name: 'John Doe',
      pickupLocation: 'Downtown',
      pickupDateTime: '2025-08-01 10:00',
      vehicleType: 'Sedan'
    },
    {
      id: 2,
      name: 'Jane Smith',
      pickupLocation: 'Uptown',
      pickupDateTime: '2025-08-01 12:00',
      vehicleType: 'SUV'
    }
  ];

  useEffect(() => {
    setUserData(UserData);
  }, []);

  const openModal = (user) => {
    setSelectedUser(user);
    const alreadyAssigned = assignedCars[user.id];
    if (alreadyAssigned) {
      setSelectedCar(alreadyAssigned.id.toString());
    } else {
      setSelectedCar('');
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setShowFuelPopup(false);
    setSelectedFuelStatus('');
    setSelectedCar('');
    setSelectedUser(null);
  };

  const handleCarSelection = (carId) => {
    setSelectedCar(carId);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedCar && selectedUser) {
      setShowFuelPopup(true);
    } else {
      alert('Please select a car');
    }
  };

  const handleFuelConfirm = () => {
    if (!selectedFuelStatus) {
      alert("Please select fuel status");
      return;
    }

    const car = availableCars.find((c) => c.id === parseInt(selectedCar));
    const carWithFuel = { ...car, fuelStatus: selectedFuelStatus };

    setAssignedCars((prev) => ({
      ...prev,
      [selectedUser.id]: carWithFuel,
    }));
    alert(`Assigned ${car.model} to ${selectedUser.name}`);
    closeModal();
  };

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl font-bold mb-6 text-gray-800">User Transportation Schedule</h1>

        <div className="overflow-x-auto bg-white shadow-lg rounded-lg border border-gray-200">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">User ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Pickup Location</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Pickup DateTime</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Vehicle Type</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Action</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {userData.map((user) => {
                const assigned = assignedCars[user.id];
                const matchingCars = availableCars.filter(car => car.type === user.vehicleType && car.status === 'Available');
                return (
                  <tr key={user.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 text-sm text-gray-600">{user.id}</td>
                    <td className="px-6 py-4 text-sm text-gray-900 font-medium">{user.name}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{user.pickupLocation}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{user.pickupDateTime}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{user.vehicleType}</td>
                    <td className="px-6 py-4 text-sm">
                      {assigned ? (
                        <button onClick={() => openModal(user)} className="text-blue-600 hover:text-blue-800 font-medium">
                          View Car 
                        </button>
                      ) : matchingCars.length > 0 ? (
                        <button onClick={() => openModal(user)} className="text-indigo-600 hover:text-indigo-800 font-medium">
                          Select Car
                        </button>
                      ) : (
                        <span className="text-gray-400">No Cars</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {isModalOpen && selectedUser && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-6 w-full max-w-lg shadow-2xl">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold text-gray-800">
                  {assignedCars[selectedUser.id] ? 'Assigned Car Details' : `Select ${selectedUser.vehicleType} for ${selectedUser.name}`}
                </h2>
                <button onClick={closeModal} className="text-gray-500 hover:text-gray-700">✕</button>
              </div>

              {assignedCars[selectedUser.id] ? (
                <div className="space-y-2 text-sm text-gray-600">
                  <p><strong>Model:</strong> {assignedCars[selectedUser.id].model}</p>
                  <p><strong>Registration No:</strong> {assignedCars[selectedUser.id].registrationNumber}</p>
                  <p><strong>Type:</strong> {assignedCars[selectedUser.id].type}</p>
                  <p><strong>Fuel Status:</strong> {assignedCars[selectedUser.id].fuelStatus}</p>
                  <img src={assignedCars[selectedUser.id].imageUrl} alt="Vehicle" className="mt-3 w-full rounded" />
                  <div className="flex justify-end pt-4">
                    <button onClick={closeModal} className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                      Close
                    </button>
                  </div>
                </div>
              ) : !showFuelPopup ? (
                <form onSubmit={handleSubmit}>
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Available {selectedUser.vehicleType}s
                    </label>
                    <div className="space-y-3 max-h-64 overflow-y-auto pr-2">
                      {availableCars
                        .filter(car => car.type === selectedUser.vehicleType && car.status === 'Available')
                        .map(car => (
                          <label
                            key={car.id}
                            className="flex items-center p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100"
                          >
                            <input
                              type="radio"
                              name="car"
                              value={car.id}
                              checked={selectedCar === car.id.toString()}
                              onChange={() => handleCarSelection(car.id.toString())}
                              className="h-4 w-4 text-indigo-600"
                            />
                            <div className="ml-3 text-sm text-gray-600">
                              <p><strong>{car.model}</strong> (Reg: {car.registrationNumber})</p>
                              <p>Fuel: {car.fuelStatus}</p>
                              <img src={car.imageUrl} alt="Vehicle" className="mt-2 w-32 rounded" />
                            </div>
                          </label>
                        ))}
                    </div>
                  </div>
                  <div className="flex justify-end space-x-3">
                    <button type="button" onClick={closeModal} className="px-4 py-2 bg-red-500 rounded-md">
                      Cancel
                    </button>
                    <button type="submit" className="px-4 py-2 bg-orange-600 text-white rounded-md">
                      Confirm
                    </button>
                  </div>
                </form>
              ) : (
                <div className="space-y-4 text-sm text-gray-700">
                  <p>You selected: <strong>{availableCars.find(c => c.id === parseInt(selectedCar))?.model}</strong></p>
                  <div>
                    <label className="block font-medium mb-1">Select Fuel Status:</label>
                    <select
                      value={selectedFuelStatus}
                      onChange={(e) => setSelectedFuelStatus(e.target.value)}
                      className="w-full border border-gray-300 rounded px-3 py-2"
                    >
                      <option value="">-- Select --</option>
                      <option value="Full">Full</option>
                      <option value="Half">Half</option>
                      <option value="Low">Low</option>
                      <option value="Empty">Empty</option>
                    </select>
                  </div>
                  <div className="flex justify-end space-x-3 pt-2">
                    <button onClick={closeModal} className="px-4 py-2 bg-gray-200 rounded-md">Cancel</button>
                    <button onClick={handleFuelConfirm} className="px-4 py-2 bg-green-600 text-white rounded-md">Confirm Assignment</button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
