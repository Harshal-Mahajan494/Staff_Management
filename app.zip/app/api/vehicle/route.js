// app/api/vehicle/route.js
export async function GET() {
  const data = [
    {
      memberId: "M001",
      memberName: "John Doe",
      pickupLocation: "City Center",
      pickupDateTime: "2025-08-05T09:00",
      returnLocation: "Main Garage",
      returnDateTime: "2025-08-06T18:00",
      vehicleType: "SUV",
      vehicleName: "Toyota Fortuner",
      registrationNumber: "MH12AB1234",
      status: "Handover"
    },
    {
      memberId: "M002",
      memberName: "Jane Smith",
      pickupLocation: "Station",
      pickupDateTime: "2025-08-04T10:00",
      returnLocation: "Depot",
      returnDateTime: "2025-08-05T16:30",
      vehicleType: "Sedan",
      vehicleName: "Honda City",
      registrationNumber: "MH14CD5678",
      status: "Return"
    }
  ];

  return new Response(JSON.stringify(data), {
    headers: { "Content-Type": "application/json" }
  });
}
