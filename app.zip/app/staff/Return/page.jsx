'use client';
import { useState, useEffect } from 'react';
import { fetchAvailableCars, postReturnData } from '@/app/api/return/route';

const placeholderUserData = [
  {
    id: 1,
    name: 'John Doe',
    returnLocation: 'Downtown',
    returnDateTime: '2025-08-06 18:00',
    registrationNumber: 'MH12AB1234',
  },
  {
    id: 2,
    name: 'Jane Smith',
    returnLocation: 'Airport',
    returnDateTime: '2025-08-06 20:00',
    registrationNumber: 'MH12CD5678',
  },
  {
    id: 3,
    name: 'Bob Johnson',
    returnLocation: 'Suburbs',
    returnDateTime: '2025-08-07 09:00',
    registrationNumber: 'MH12EF9012',
  },
];

export default function ReturnDashboard() {
  const [userData, setUserData] = useState([]);
  const [availableCars, setAvailableCars] = useState([]);
  const [returnedCars, setReturnedCars] = useState({});
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedFuelStatus, setSelectedFuelStatus] = useState('');

  useEffect(() => {
    setUserData(placeholderUserData);
    fetchAvailableCars().then(setAvailableCars);
  }, []);

  const openModal = (user) => {
    setSelectedUser(user);
    setSelectedFuelStatus('');
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedUser(null);
  };

  const handleReturn = async () => {
    const car = availableCars.find(
      (c) => c.registrationNumber === selectedUser.registrationNumber
    );
    if (!car || !selectedFuelStatus) {
      alert('Please select fuel status.');
      return;
    }

    const returnPayload = {
      userId: selectedUser.id,
      userName: selectedUser.name,
      returnLocation: selectedUser.returnLocation,
      returnDateTime: selectedUser.returnDateTime,
      registrationNumber: selectedUser.registrationNumber,
      model: car.model,
      fuelStatus: selectedFuelStatus,
    };

    try {
      const res = await postReturnData(returnPayload);
      if (res.status === 200) {
        const carWithFuel = { ...car, fuelStatus: selectedFuelStatus };
        setReturnedCars((prev) => ({
          ...prev,
          [selectedUser.id]: carWithFuel,
        }));
        alert(`✅ Returned ${car.model} for ${selectedUser.name}`);
        closeModal();
      }
    } catch (error) {
      console.error('❌ Error posting return data:', error);
      alert('Error saving return info');
    }
  };

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl font-bold mb-6 text-gray-800">Vehicle Return Schedule</h1>

        <div className="overflow-x-auto bg-white shadow-lg rounded-lg border border-gray-200">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">User ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Return Location</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Return DateTime</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Reg No</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Action</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {userData.map((user) => {
                const returned = returnedCars[user.id];
                return (
                  <tr key={user.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 text-sm text-gray-600">{user.id}</td>
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{user.name}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{user.returnLocation}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{user.returnDateTime}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{user.registrationNumber}</td>
                    <td className="px-6 py-4 text-sm">
                      <button
                        onClick={() => openModal(user)}
                        className="text-green-600 hover:text-green-800 font-medium"
                      >
                        {returned ? 'View' : 'Return'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Modal */}
        {isModalOpen && selectedUser && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-6 w-full max-w-md shadow-2xl">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold text-gray-800">Return Vehicle</h2>
                <button onClick={closeModal} className="text-gray-500 hover:text-gray-700">✕</button>
              </div>

              {returnedCars[selectedUser.id] ? (
                <div className="space-y-3 text-sm text-gray-700">
                  <p><strong>Returned Car:</strong> {returnedCars[selectedUser.id].model}</p>
                  <p><strong>Reg No:</strong> {returnedCars[selectedUser.id].registrationNumber}</p>
                  <p><strong>Fuel Status:</strong> {returnedCars[selectedUser.id].fuelStatus}</p>
                  <img src={returnedCars[selectedUser.id].imageUrl} alt="Vehicle" className="w-full rounded mt-3" />
                  <div className="pt-4 text-right">
                    <button onClick={closeModal} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                      Close
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4 text-sm text-gray-700">
                  <div>
                    <p><strong>Car:</strong> {
                      availableCars.find(
                        (c) => c.registrationNumber === selectedUser.registrationNumber
                      )?.model || 'Not Found'
                    }</p>
                    <p><strong>Reg No:</strong> {selectedUser.registrationNumber}</p>
                  </div>

                  <div>
                    <label className="block font-medium mb-1">Fuel Status:</label>
                    <select
                      value={selectedFuelStatus}
                      onChange={(e) => setSelectedFuelStatus(e.target.value)}
                      className="w-full border border-gray-300 rounded px-3 py-2"
                    >
                      <option value="">-- Select --</option>
                      <option value="Full">Full</option>
                      <option value="Half">Half</option>
                      <option value="Empty">Empty</option>
                    </select>
                  </div>

                  <div className="flex justify-end gap-3 pt-2">
                    <button onClick={closeModal} className="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300">
                      Cancel
                    </button>
                    <button onClick={handleReturn} className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
                      Confirm Return
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
